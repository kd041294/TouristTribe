<?php

namespace App\Http\Controllers\user;
use App\Meal;
use App\Hotel;
use Validator;
use App\Midtrip;
use App\Transfer;
use App\TourOperator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Libraries\TripLibrary;
use App\Http\Controllers\Controller;

class TripControllers extends Controller
{
    public function seeComp(Request $req, $comp_name, $loc){
        
        return $this->see($req, $loc, $comp_name);
    }

    public function see(Request $req,$loc, $comp_name = null) {
        //Receive Data
        
        $tour_operator_id = TourOperator::get_id_by_company_name($comp_name);
        $commission_percent = TourOperator::get_commission_by_company_name($comp_name);
        
        $trip_all_price_details = [];
        date_default_timezone_set("Asia/Calcutta");
        $calculation = $req -> cal ?? "no";
        $nop = $req -> nop ?? 2;
        $nor = $req -> nor ?? 1;
        $bt = $req -> bt ?? 2;
        $nod = $req -> nod ?? 0;
        $trip_date = $req -> trip_date ?? date("Y-m-d");

        //data get
        if($nod == 0){
            $data = DB::table('trips')
                    ->join('per_head_extra_fees', 'trips.per_head_extra_fees_id', '=', 'per_head_extra_fees.id')
                    ->join('meals','trips.meal','=','meals.id')
                    ->join('transfers','trips.transfers','=','transfers.id')
                    ->join('locations','trips.location_id','=','locations.id')
                    ->join('tour_operators','trips.tour_operator_id','=','tour_operators.id')
                    ->join('booking_details as bd', 'bd.trip_id', '=', 'trips.id')
                    ->select
                        (
                            'per_head_extra_fees.per_head_cost', 'per_head_extra_fees.fee_details',
                            'trips.id','trips.trip_name','trips.no_of_days','trips.no_of_nights',
                            'trips.allGender','trips.onlyMens','trips.onlyWomens','trips.allCast',
                            'trips.buddhismCast','trips.hinduCast','trips.sikhismCast','trips.islamCast',
                            'trips.christianCast','trips.hotels','trips.midtrips','meals.per_head_cost as mealPrice',
                            'transfers.name as vehicalName','transfers.type as vehicalType',
                            'transfers.total_person as vehicalTotalPerson',
                            'transfers.total_cost as vehicalCost',
                            'locations.type','locations.total_member_size','locations.min_family_member',
                            'tour_operators.comp_name','tour_operators.gst', 'bd.starting_date'
                        )
                    ->where('trips.location_name',$loc)
                    ->get();
        }
        else{
            $data = DB::table('trips')
                    ->join('per_head_extra_fees', 'trips.per_head_extra_fees_id', '=', 'per_head_extra_fees.id')
                    ->join('meals','trips.meal','=','meals.id')
                    ->join('transfers','trips.transfers','=','transfers.id')
                    ->join('locations','trips.location_id','=','locations.id')
                    ->join('tour_operators','trips.tour_operator_id','=','tour_operators.id')
                    ->select
                        (
                            'per_head_extra_fees.per_head_cost', 'per_head_extra_fees.fee_details',
                            'trips.id','trips.trip_name','trips.no_of_days','trips.no_of_nights',
                            'trips.allGender','trips.onlyMens','trips.onlyWomens','trips.allCast',
                            'trips.buddhismCast','trips.hinduCast','trips.sikhismCast','trips.islamCast',
                            'trips.christianCast','trips.hotels','trips.midtrips','meals.per_head_cost as mealPrice',
                            'transfers.name as vehicalName','transfers.type as vehicalType',
                            'transfers.total_person as vehicalTotalPerson',
                            'transfers.total_cost as vehicalCost',
                            'locations.type','locations.total_member_size','locations.min_family_member',
                            'tour_operators.comp_name','tour_operators.gst'
                        )
                    ->where('trips.location_name',$loc)
                    ->where('trips.no_of_days',$nod)
                    ->get();
        }
        // echo json_encode($data);die;
        $incrementData = 0;
        $numberOfTrip = count(array($loc));
        
        
        foreach ($data as $datas) {
            if($data != '[]'){
                $tripPrices = 0;    
                //Hotels Data start
                $hotelsString = $datas -> hotels;
                $hotelArray = explode(",", $hotelsString);
                $hotelCount = count($hotelArray);

                $inc = 0;
                $single_bed_type_cost = 0;
                $double_bed_type_cost = 0;
                $triple_bed_type_cost = 0;

                for($i = 0; $i < $hotelCount; $i++) {
                    $hotelId = $hotelArray[$i];
                    if($hotelId != '000') {
                            $hotelData = Hotel::find($hotelId);
                        if($hotelData['single_bed_type_cost']){
                            $single_bed_type_cost = $single_bed_type_cost + $hotelData['single_bed_type_cost'];
                        }
                        if($hotelData['double_bed_type_cost']){
                            $double_bed_type_cost = $double_bed_type_cost + $hotelData['double_bed_type_cost'];
                        }
                        if($hotelData['triple_bed_type_cost']){
                            $triple_bed_type_cost = $triple_bed_type_cost + $hotelData['triple_bed_type_cost'];
                        }         
                        $hotalDataNew[$inc] = json_decode($hotelData);
                        $inc = $inc + 1;
                    }
                }

                $hotelIncrementData[$incrementData] = $hotalDataNew;
                //Hotels Data stop

                //midtrip Data start
                $midtripString = $datas -> midtrips;
                $midtripArray = explode(",", $midtripString);
                $midtripCount = count($midtripArray);
                    
                for($i = 0; $i < $midtripCount; $i++) {
                    $midtripId = $midtripArray[$i];
                    $midtripData = Midtrip::find($midtripId);
                    $midtripDataNew[$i] = json_decode($midtripData);
                }
                $midtripIncrementData[$incrementData] = $midtripDataNew; 
                //midtrip Data stop
                
                //Bokking Number Start
                $bookingCount = DB::table('booking_details')
                                ->where('trip_id',$datas -> id)
                                ->where('bookingDate',$trip_date)
                                ->get();

                $numberOfPersonBooking = 0;
                foreach ($bookingCount as $bookingCounts) {
                    $numberOfPersonBooking = $numberOfPersonBooking + $bookingCounts -> no_of_person;
                }
                $bookingIncrementData[$incrementData] = $numberOfPersonBooking;
                //Booking Number Close

                //Vehical Price Calculations Start
                $trip_capacity = (int)$datas -> total_member_size;
                $vehical_capacity = (int)$datas -> vehicalTotalPerson;
                $vehical_price = (int)$datas -> vehicalCost;

                $vc = $vehical_capacity;
                $vp = $vehical_price;
                $ec = $numberOfPersonBooking;
                $nc = $nop;
                            
                $c = $ec + $nc;//total_seat
                if($trip_capacity >= $c){
                    
                $a=$vp/$vc;

                if($ec==0 && $nc<=$vc)
                {
                    // $p=$a*$nc;
                    $p = $vp;
                }
                else if($ec==0 && $nc>$vc)
                {
                    $b=$nc%$vc;
                    $d=(int)($nc/$vc);
                    if($b!=0)
                    {
                        $d++;
                        $p=$d*$vp;
                    }
                    else
                    {
                        $p=$d*$vp;
                    }
                }
                else if($ec!=0 && $c<=$vc)
                {
                    $p=$a*$nc;
                }
                else if($ec!=0 && $c>$vc)
                {
                    $b=$nc%$vc;    
                    $d=(int)($nc/$vc);
                    $e=$ec%$vc;
                    $e=$vc-$e;
                    if($b<=$e)
                    {
                        $p1=$a*$e;
                        $p2=$d*$vp;
                        $p=$p1+$p2;
                    }
                    else
                    {
                        $d++;
                        $p=$d*$vp;
                    }
                }
                    
                    
                    // if($vc < $c){
                    //     $b = $c % $vc;
                    //     $cc = $c / $vc;
                    
                    //     $a0 = $nc - $b;
                    //     $a1 = $vp;
                    //     $a2 = $vp/$vc;
                    //     $a3 = $a2 * $a0;
                    //     if($b == 0){
                    //         $p = $a3;
                    //     }
                    //     else{
                    //         $p = $a3 + $vp;
                    //         //vehical price is $p
                    //     }
                    // }
                    // else{
                    //     $s = $vp/$c;
                    //     $p = $s * $nc;
                    // }         
                    $tripError[$incrementData] = "Possible";   
                }
                else{
                    //echo "Sorry booking not possible";
                    $p = 0;
                    $tripError[$incrementData] = "Not Possible";
                }
                /* vehical price calculations close*/

                // license fees calculation
                $license_fee_amount = $nop*$datas->per_head_cost;

                //meal Prices
                $mealPrice = 0;
                $mealPrice = $nop * ($datas -> no_of_days * $datas -> mealPrice);
                //All price Calculation 

                if($bt == 1){
                    $tripPrices = $nor * $single_bed_type_cost;
                }
                elseif($bt == 2){
                    $tripPrices = $nor * $double_bed_type_cost;  
                }
                else{
                    $tripPrices = $nor * $triple_bed_type_cost;   
                }

                $tripPrices = $tripPrices +  $p + $mealPrice + $license_fee_amount;
                //Touristtribe 
                $tripPrices = $tripPrices * 1.08;//touristtribe
                // echo $tripPrices." ";
                
                // echo $tripPrices."<br>";
                
                if($datas -> gst){
                    $tripPrices = $tripPrices * 1.05;//gst
                }

                $tripPrices = $tripPrices * 1.02;//payumoney gateway charges

                if($commission_percent){
                    $tripPrices = $tripPrices * (1+$commission_percent);//tour_operator_commission
                }

                $tripPricesData[$incrementData] = (int)$tripPrices;
                $incrementData = $incrementData + 1;

            }
        }

        $trip_data = TripLibrary::get_trip_calculated_details($loc, $nod, $nop, $nor, $bt, $trip_date);
         $trip_data["is_comp_passed"] = $tour_operator_id ? 1 : 0;
         
       // $trip_data = \TripLibrary::get_trip_calculated_details($loc, $nod, $nop, $nor, $bt, $trip_date, $trip_id, $params = []);
               // echo json_encode($trip_data);die;
               
        if($trip_data["data"] != '[]'){
            return view('User.trip_details', $trip_data);
        }
        else{
            return "Sorry Trip Not Found in $nod day";
        }
    }
}
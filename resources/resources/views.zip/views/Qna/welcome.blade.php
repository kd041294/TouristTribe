<!DOCTYPE html>
<html>
<head>
	<title>QNA</title>
</head>
<body>
	<h2 style="text-align: center">Developing new era</h2>
</body>
</html>
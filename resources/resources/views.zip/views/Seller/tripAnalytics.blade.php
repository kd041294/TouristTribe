@extends('Seller.layouts.app')


@section('data')
	<h1 class="text-center">Kam abhi ho raha hai : )</h1>
@endsection
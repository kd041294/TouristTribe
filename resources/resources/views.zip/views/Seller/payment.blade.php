@extends('Seller.layouts.app')


@section('data')
	<h1 class="text-center">We are working on it : )</h1>
@endsection
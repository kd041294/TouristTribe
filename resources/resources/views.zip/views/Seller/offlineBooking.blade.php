@extends('Seller.layouts.app')


@section('data')
	<h4 class="text-center">This section will appear after 7 days</h4>
	<p class="text-center">Meanwhile, please stay tuned...</p>
@endsection
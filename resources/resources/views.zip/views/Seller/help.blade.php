@extends('Seller.layouts.app')


@section('data')
	<h4 class="text-center">We are working on this page</h4>
    <p class="text-center"><a href="tel:8479953731">Call us at 8479953731</a></p>
@endsection
@extends('Seller.layouts.app')


@section('data')
	<h4 class="text-center">Your Profile is getting ready</h4>
@endsection